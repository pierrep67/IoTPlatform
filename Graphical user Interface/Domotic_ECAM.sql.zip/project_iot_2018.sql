-- phpMyAdmin SQL Dump
-- version 4.5.5.1
-- http://www.phpmyadmin.net
--
-- Client :  127.0.0.1
-- Généré le :  Sam 13 Janvier 2018 à 11:04
-- Version du serveur :  5.7.11
-- Version de PHP :  5.6.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `project_iot_2018`
--

-- --------------------------------------------------------

--
-- Structure de la table `linear_regression`
--

CREATE TABLE `linear_regression` (
  `ID_Linear` int(100) UNSIGNED NOT NULL COMMENT ' ',
  `Date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT ' ',
  `First_Value` decimal(20,10) NOT NULL COMMENT ' ',
  `Slope` decimal(20,10) NOT NULL COMMENT ' ',
  `ID_Room` int(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `previsionnal`
--

CREATE TABLE `previsionnal` (
  `ID_Previsionnal` int(100) UNSIGNED NOT NULL COMMENT ' ',
  `Date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT ' ',
  `ARIMA_Temperature` decimal(20,2) NOT NULL COMMENT ' ',
  `ML_Temperature` decimal(20,2) NOT NULL COMMENT ' ',
  `ID_Room` int(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `room`
--

CREATE TABLE `room` (
  `ID_Room` int(100) UNSIGNED NOT NULL COMMENT ' ',
  `Room_Name` text CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL COMMENT ' '
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `sensor`
--

CREATE TABLE `sensor` (
  `ID_Sensor` int(100) UNSIGNED NOT NULL,
  `Date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Time` time NOT NULL,
  `Temperature` decimal(20,2) NOT NULL COMMENT ' ',
  `CO2` decimal(20,2) NOT NULL COMMENT ' ',
  `Humidity` decimal(20,2) NOT NULL COMMENT ' ',
  `Smoke` tinyint(1) NOT NULL,
  `ID_Room` int(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Index pour les tables exportées
--

--
-- Index pour la table `linear_regression`
--
ALTER TABLE `linear_regression`
  ADD PRIMARY KEY (`ID_Linear`),
  ADD KEY `ID_Room` (`ID_Room`);

--
-- Index pour la table `previsionnal`
--
ALTER TABLE `previsionnal`
  ADD PRIMARY KEY (`ID_Previsionnal`),
  ADD KEY `ID_Room` (`ID_Room`);

--
-- Index pour la table `room`
--
ALTER TABLE `room`
  ADD PRIMARY KEY (`ID_Room`);

--
-- Index pour la table `sensor`
--
ALTER TABLE `sensor`
  ADD PRIMARY KEY (`ID_Sensor`),
  ADD KEY `ID_Room` (`ID_Room`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
